package com.example.weather;

import java.util.ArrayList;
import java.util.List;

public class Graph {
    public Graph() {

    }
}
